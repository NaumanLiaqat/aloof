#include "stdafx.h"
#include "CppUnitTest.h"
#include"..\ConsoleApplication2\Source.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			// TODO: Your test code here
			stack obj;
			Assert::AreEqual(1, obj.isEmpty());
		}
		TEST_METHOD(TestMethod2)
		{
			// TODO: Your test code here
			stack obj;
			Assert::AreEqual(0, obj.isFull());
		}

		

	};
}