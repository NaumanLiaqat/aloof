#include<iostream>
#define SIZE 10
using namespace std;

class stack{

public:
	stack(){
		top = -1;
	};
	int siz[SIZE];
	int top;
	int isEmpty();
	int isFull();
	int push(int);
	int pop();
	void display();
};


int stack::isEmpty(){
	if (top == -1)
		return 1;
	else
		return 0;
}

int stack::isFull(){
	if (top == (SIZE - 1))
		return 1;
	else
		return 0;

}

int stack::push(int n){
	if (isFull())
	{
		return 0;
	}
	top++;
	siz[top] = n;
	return n;
}

int stack::pop(){
	int x;
	if (isEmpty())
		return 0;
	x = siz[top];
	return x;
}

void stack::display(){
	int i;
	for (i = (top); i >= 0; i--)
		cout << siz[i] << " ";
	cout << endl;
}

void main(){

	stack obj;
	obj.push(1);
	obj.push(2);
	obj.push(3);
	obj.push(4);
	obj.push(5);
	obj.push(6);
	obj.push(7);
	obj.push(8);
	obj.push(9);
	obj.push(10);
	obj.display();
	cout << "\nPopped element is: " << obj.pop();
	getchar();



}