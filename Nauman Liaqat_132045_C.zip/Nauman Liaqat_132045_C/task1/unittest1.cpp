#include "stdafx.h"
#include "CppUnitTest.h"
#include"..\ConsoleApplication1\Source.cpp"


using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		
		TEST_METHOD(TestMethod1)
		{
	
			// TODO: Your test code here
			fact f;
			Assert::AreEqual(2,f.factorial(2));
		}
		TEST_METHOD(TestMethod2)
		{

			// TODO: Your test code here
			fact f;
			Assert::AreNotEqual(10, f.factorial(2));
		}
		TEST_METHOD(TestMethod3)
		{

			// TODO: Your test code here
			fact f;
			Assert::AreNotSame(-2, f.factorial(2));
		}


	};
}