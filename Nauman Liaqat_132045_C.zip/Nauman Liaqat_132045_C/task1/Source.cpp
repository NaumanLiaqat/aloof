#include <iostream>
#include"Header.h"
using namespace std;
void main(void) {
	fact f;
	int number;
	cout << "Enter a positive integer: ";
	cin >> number;
	if (number < 0)
		cout << "That is a negative integer.\n";
	else
		cout << "Factorial is: " << f.factorial(number) << endl;
}